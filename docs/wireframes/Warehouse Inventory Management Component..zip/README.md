# DMIS EP-03 — Sprint 1 Wireframes

Low-fidelity HTML wireframes for the **Inventory & Stockpile** module of Jamaica's Disaster Management Information System (ODPEM).

> **Cutover model.** DMIS inventory begins at zero. No legacy migration. A warehouse becomes operational only after a posted Opening Balance.

## Pages

| # | Route | File |
|---|---|---|
| 1 | `/inventory/dashboard` | [`inventory/dashboard.html`](inventory/dashboard.html) |
| 2 | `/inventory/items/{id}/provenance` | [`inventory/items/sample/provenance.html`](inventory/items/sample/provenance.html) |
| 3 | `/inventory/opening-balance/list` | [`inventory/opening-balance/list.html`](inventory/opening-balance/list.html) |
| 4 | `/inventory/opening-balance/wizard` | [`inventory/opening-balance/wizard.html`](inventory/opening-balance/wizard.html) |
| 5 | `/inventory/opening-balance/{id}/detail` | [`inventory/opening-balance/sample/detail.html`](inventory/opening-balance/sample/detail.html) |
| 6 | `/inventory/opening-balance/approval-queue` | [`inventory/opening-balance/approval-queue.html`](inventory/opening-balance/approval-queue.html) |
| 7 | `/inventory/exceptions` | [`inventory/exceptions.html`](inventory/exceptions.html) |
| 8 | `/inventory/pick-confirm` | [`inventory/pick-confirm.html`](inventory/pick-confirm.html) |
| 9 | `/inventory/reservations` | [`inventory/reservations.html`](inventory/reservations.html) |
| 10 | — | [`diagrams.html`](diagrams.html) |

Master-data pages (`/master-data/...`) extend the existing project pattern and are not redesigned here.

## Design tokens

| Token | Value | Where |
|---|---|---|
| `--ops-surface` | near-white page bg | body |
| `--ops-section` | white | cards |
| `--ops-card` | very light grey | inset cards |
| `--ops-ink` | near-black | primary text |
| `--ops-outline` | light grey | borders |
| `--ops-radius-md` | 10px | cards / inputs |
| `--ops-radius-pill` | 999px | chips / pills |

**Status palette (always pair with text + icon, never colour alone):**

| Tone | Hex |
|---|---|
| GREEN — OK | `#1F8A4C` |
| AMBER — WARNING | `#C77800` |
| RED — CRITICAL | `#B3261E` |
| YELLOW — WATCH | `#C58D00` |
| GREY — NEUTRAL | `#6E7780` |

**Type:** Inter for body, Caveat / Architects Daughter for handwritten low-fi annotations. Tabular numerals on all numeric values.
**Spacing:** 8 px base; cards 16–24 px padding; 12 px gap between cards.

## A note on stylesheet handling

The brief asks for inline CSS. To keep 10 pages maintainable while remaining fully offline-runnable (no server, just `file://` open), the shared tokens live in `assets/wireframe.css` and are linked from each page. Relative `<link>` works in `file://`, so pages remain independently viewable. If true inlining is needed for handoff, run a one-pass concat of `assets/wireframe.css` into a `<style>` block per file.

`assets/shell.js` renders the shared topbar + sidebar so each page only writes its main content via `<template id="page-content">`.

## Cutover model in the wireframes

- Empty/zero dashboard state for new warehouses + persistent banner.
- "Pending Opening Balance" badge shown wherever a warehouse appears.
- KPIs explicitly exclude warehouses that are not yet `INVENTORY_ACTIVE`.
- OB Wizard explicitly disallows backfill; "legacy snapshot" link is reference-only.
- Valuation basis panel surfaces all three paths — `ITEM_UNIT_COST`, `CATEGORY_ESTIMATE`, `SAGE_DEFERRED_EXECUTIVE_ROUTE`. Missing cost **never** lowers approval tier.
- Segregation of duties enforced visibly — Approve button disabled with hint when actor == requester.

## Accessibility

- Semantic `<main>`, `<nav>`, `<table>`, `<aside>`, `<header>`.
- Skip link, keyboard-focusable controls, `aria-label` on icon-only buttons, `role="tablist"` / `role="tab"` / `aria-selected`.
- 4.5:1 text contrast on tinted chip backgrounds (verified against the supplied palette).
- Status indicators always combine colour + icon + text label.
- `aria-live="polite"` on the offline banner.
- Skeleton placeholders for loading; cards never revert to skeleton on refetch.

## Offline / slow-network behaviour represented

- Persistent offline banner (preview with `Alt+O` on any page).
- Wizard step 1 + step 2 auto-save server-side on each blur (PATCH); steps 3–4 are server-state-only. The header banner above step 2 indicates "Auto-saving · server draft …".

## Next steps — Angular component file paths

When this wireframe set lands in code, target the following Angular component files under
`frontend/src/app/inventory/`:

```
frontend/src/app/inventory/
  pages/
    dashboard/
      inventory-dashboard.component.ts        ← page 1
    item-provenance/
      item-provenance.component.ts            ← page 2
    opening-balance/
      ob-list/ob-list.component.ts            ← page 3
      ob-wizard/ob-wizard.component.ts        ← page 4
        steps/header-step.component.ts
        steps/lines-step.component.ts
        steps/evidence-step.component.ts
        steps/review-step.component.ts
      ob-detail/ob-detail.component.ts        ← page 5
      ob-approval-queue/                      ← page 6
        ob-approval-queue.component.ts
    exceptions/
      exceptions.component.ts                 ← page 7
    pick-confirm/
      pick-confirm.component.ts               ← page 8
    reservations/
      reservations.component.ts               ← page 9
  shared/
    components/
      status-chip/status-chip.component.ts
      severity-badge/severity-badge.component.ts
      expiry-countdown/expiry-countdown.component.ts
      freshness-pill/freshness-pill.component.ts
      evidence-thumbnail/evidence-thumbnail.component.ts
      kpi-card/kpi-card.component.ts
      data-table/data-table.component.ts
      step-tracker/dmis-step-tracker.component.ts   (existing, reuse)
      confirm-dialog/confirm-dialog.component.ts
      empty-state/empty-state.component.ts
      skeleton/skeleton-row.component.ts
      toast-inline/toast-inline.component.ts
      valuation-basis-panel/valuation-basis-panel.component.ts
      warehouse-state-badge/warehouse-state-badge.component.ts
```

Place tenant-scoped state in `inventory/state/` (NgRx feature slice or signal store), and the OB workflow service in `inventory/services/opening-balance.service.ts`.
