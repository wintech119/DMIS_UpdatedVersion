// Renders the shared topbar + sidebar so each page only writes its main content.
// Usage: place <div id="dmis-shell" data-active="dashboard" data-freshness="high" data-refreshed="14 min ago" data-base="../"></div>
// then <script src="../assets/shell.js"></script> at end of body.
(function () {
  const root = document.getElementById('dmis-shell');
  if (!root) return;
  const active = root.dataset.active || '';
  const fresh  = (root.dataset.freshness || 'high').toLowerCase();
  const refreshed = root.dataset.refreshed || '14 min ago';
  const base = root.dataset.base || '../';
  const userName = root.dataset.user || 'Kemar M.';
  const userRole = root.dataset.role || 'Logistics Manager';

  const links = [
    { id: 'dashboard',   href: 'inventory/dashboard.html',                     label: 'Dashboard',        icon: '▥' },
    { id: 'warehouse-inventory', href: 'inventory/warehouse-inventory.html',   label: 'Warehouse Inventory', icon: '▦' },
    { id: 'ob-list',     href: 'inventory/opening-balance/list.html',          label: 'Opening Balances', icon: '⊞' },
    { id: 'approval',    href: 'inventory/opening-balance/approval-queue.html',label: 'Approval Queue',   icon: '✓' },
    { id: 'exceptions',  href: 'inventory/exceptions.html',                    label: 'Exceptions',       icon: '!' },
    { id: 'reservations',href: 'inventory/reservations.html',                  label: 'Reservations',     icon: '⌗' },
    { id: 'pick',        href: 'inventory/pick-confirm.html',                  label: 'Pick Confirm',     icon: '⊟' },
    { id: 'provenance',  href: 'inventory/items/sample/provenance.html',       label: 'Item Provenance',  icon: '↺' },
  ];
  const refLinks = [
    { id: 'diagrams', href: 'diagrams.html', label: 'Workflow Diagrams', icon: '⌬' },
    { id: 'index',    href: 'index.html',    label: 'All Pages',         icon: '☰' },
  ];

  const freshClass = fresh === 'low' ? 'low' : fresh === 'med' ? 'med' : 'high';
  const freshLabel = fresh === 'low' ? 'LOW' : fresh === 'med' ? 'MEDIUM' : 'HIGH';

  const navHTML = `
    <span class="nav__group">Inventory</span>
    ${links.map(l => `<a href="${base}${l.href}" class="${l.id === active ? 'is-active' : ''}"><span class="nav__icon" aria-hidden="true">${l.icon}</span> ${l.label}</a>`).join('')}
    <span class="nav__group">Reference</span>
    ${refLinks.map(l => `<a href="${base}${l.href}" class="${l.id === active ? 'is-active' : ''}"><span class="nav__icon" aria-hidden="true">${l.icon}</span> ${l.label}</a>`).join('')}
  `;

  root.innerHTML = `
    <a href="#main" class="skip-link">Skip to main content</a>
    <div class="offline-banner" role="status" aria-live="polite" hidden id="offlineBanner">
      <span class="offline-banner__dot"></span>
      Working offline — changes will sync when connection returns.
    </div>
    <div class="shell">
      <aside class="shell__sidebar" id="sidebar" aria-label="Primary">
        <div class="brand">
          <span class="brand__mark" aria-hidden="true">✦</span>
          DMIS · EP-03
        </div>
        <nav class="nav" aria-label="Inventory">${navHTML}</nav>
      </aside>
      <header class="shell__topbar">
        <button class="menu-toggle" aria-label="Open menu" aria-controls="sidebar" onclick="document.getElementById('sidebar').classList.toggle('is-open')">≡</button>
        <label class="search">
          <span aria-hidden="true">⌕</span>
          <input type="search" placeholder="Search items, batches, OB numbers…" aria-label="Search" />
        </label>
        <div class="topbar__spacer"></div>
        <span class="freshness freshness--${freshClass}" title="Data freshness: ${freshLabel}">
          <span class="freshness__dot" aria-hidden="true"></span>
          <span><strong>${freshLabel}</strong> freshness</span>
          <span class="freshness__time">· refreshed ${refreshed}</span>
        </span>
        <div class="topbar__user" aria-label="Current user">
          <span class="topbar__avatar" aria-hidden="true">${userName.split(' ').map(s => s[0]).join('').slice(0,2)}</span>
          <span>${userName} <span class="note">· ${userRole}</span></span>
        </div>
      </header>
      <main class="shell__main" id="main">${root.dataset.contentHolder ? '' : ''}<div id="page-main"></div></main>
    </div>
  `;

  // move any pre-existing content from <template id="page-content"> into #page-main
  const tpl = document.getElementById('page-content');
  if (tpl) document.getElementById('page-main').append(tpl.content.cloneNode(true));

  // simulate offline toggle (Alt+O)
  document.addEventListener('keydown', e => {
    if (e.altKey && e.key.toLowerCase() === 'o') {
      const b = document.getElementById('offlineBanner');
      b.hidden = !b.hidden;
    }
  });

  // Tablists
  document.querySelectorAll('[role="tablist"]').forEach(group => {
    group.addEventListener('click', e => {
      const t = e.target.closest('.tab');
      if (!t) return;
      group.querySelectorAll('.tab').forEach(x => {
        x.classList.toggle('is-active', x === t);
        x.setAttribute('aria-selected', x === t ? 'true' : 'false');
      });
    });
  });
})();
